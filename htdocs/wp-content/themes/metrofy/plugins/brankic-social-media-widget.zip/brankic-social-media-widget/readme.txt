=== Brankic Social Media Widget ===
Contributors: brankic1979
Donate link: http://themeforest.net/user/Brankic1979/portfolio
Tags: social, media, network, icons, animated, hover, brankic1979, facebook, twitter, google, plus, linkedin
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Social media icons with nice hover vertical animation

== Description ==

Social media inline icons with nice hover effect (vertical slide with color change). 49 icons included (aim, apple, behnace, blogger, cargo, delicious, deviantart, digg, dopple, dribbble, 
ember, evernote, facebook, flickr, forrst, github, google, googleplus, gowalla, grooveshark, html5, icloud, lastfm, linkedin, metacafe, mixx, myspace,
netvibes, newsvine, orkut, paypal, picasa, pinterest, plurk, posterous, reddit, rss, skype, stumbleupon, techorati, tumblr, twitter, vimeo, wordpress, yahoo,
yelp, youtube, zerply, zootool) 

Live demo you can see in footer [of our demo site](http://demo.brankic.net/bigbangwp/2012/07/divinum-dare-humanum-accipere/ "Our demo site")


== Installation ==

This section describes how to install the plugin and get it working.


1. Upload bra_social_media.zip to plugins, like any other plugin, or upload unzipped folder bra_social_media to wp-content/plugins/
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to Widgets and use Brankic Social Media Widget in sidebar you want

== Frequently Asked Questions ==

1. for any questions, error report and suggestions please email support@brankic.net or visit http://www.brankic1979.com

== Screenshots ==

1. Example 1
2. Example 2
3. Example 3
4. Widget admin

== Changelog ==

= 1.8 =
* jQuery backgound color selector
* Added screenshots

= 1.7 =
* Some CSS fixes, and backgound color selector

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.1 =
49 icons included
